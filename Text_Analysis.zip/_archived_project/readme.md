# Welcome to Text Analysis

## Background
 Please add some text to describe some background of the project
## Data 
 Please add some text to descirbe your data 
## Model(s) 
 Please add some text to descirbe your model(s)
